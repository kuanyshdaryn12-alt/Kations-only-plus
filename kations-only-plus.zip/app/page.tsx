 "use client";

import { FormEvent, useEffect, useRef, useState } from "react";

type Message = { role: "user" | "assistant"; content: string; image?: string };
type Chat = { id: string; title: string; messages: Message[]; updatedAt: number };

const STORAGE_KEY = "kations-only-plus-chats-v1";
const starters = [
  { icon: "✦", title: "Explain something", prompt: "Explain a difficult topic in simple terms." },
  { icon: "⌘", title: "Write something", prompt: "Help me write a clear, engaging text about..." },
  { icon: "◈", title: "Make a plan", prompt: "Help me make a practical step-by-step plan for..." },
  { icon: "◎", title: "Spark an idea", prompt: "Give me some original ideas for..." },
];

function makeChat(): Chat {
  return { id: crypto.randomUUID(), title: "New conversation", messages: [], updatedAt: Date.now() };
}

export default function Home() {
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeId, setActiveId] = useState("");
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [imageMode, setImageMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const activeChat = chats.find(c => c.id === activeId);
  const messages = activeChat?.messages ?? [];

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const saved: Chat[] = raw ? JSON.parse(raw) : [];
      if (saved.length) {
        setChats(saved);
        setActiveId(saved[0].id);
      } else {
        const first = makeChat();
        setChats([first]);
        setActiveId(first.id);
      }
    } catch {
      const first = makeChat();
      setChats([first]);
      setActiveId(first.id);
    }
  }, []);

  useEffect(() => {
    if (chats.length) localStorage.setItem(STORAGE_KEY, JSON.stringify(chats));
  }, [chats]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, busy]);

  function newChat() {
    const chat = makeChat();
    setChats(prev => [chat, ...prev]);
    setActiveId(chat.id);
    setInput("");
    setImageMode(false);
    setNotice("");
    setSidebarOpen(false);
    setTimeout(() => inputRef.current?.focus(), 50);
  }

  function updateMessages(id: string, next: Message[]) {
    setChats(prev => prev.map(c => c.id === id ? {
      ...c,
      messages: next,
      title: c.messages.length === 0 && next[0]?.role === "user"
        ? next[0].content.slice(0, 34) || "New conversation"
        : c.title,
      updatedAt: Date.now()
    } : c));
  }

  async function submitMessage(event?: FormEvent, preset?: string) {
    event?.preventDefault();
    const prompt = (preset ?? input).trim();
    if (!prompt || busy || !activeId) return;
    setInput("");
    setNotice("");
    const current = [...messages, { role: "user" as const, content: prompt }];
    updateMessages(activeId, current);
    setBusy(true);

    try {
      if (imageMode) {
        const response = await fetch("/api/images", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Image generation failed.");
        updateMessages(activeId, [...current, {
          role: "assistant", content: data.revised_prompt || "Here’s your image.",
          image: data.image
        }]);
      } else {
        const response = await fetch("/api/chat", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ messages: current.map(m => ({ role: m.role, content: m.content })) })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "The AI request failed.");
        updateMessages(activeId, [...current, { role: "assistant", content: data.reply }]);
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "Something went wrong.";
      setNotice(message);
      updateMessages(activeId, [...current, {
        role: "assistant",
        content: "I couldn’t complete that request. Check that the site owner has configured the AI API key, then try again."
      }]);
    } finally {
      setBusy(false);
      setImageMode(false);
      inputRef.current?.focus();
    }
  }

  function startVoiceInput() {
    const w = window as Window & { SpeechRecognition?: new () => SpeechRecognition; webkitSpeechRecognition?: new () => SpeechRecognition };
    const Speech = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Speech) {
      setNotice("Voice input is not supported by this browser. Try Chrome on Android or desktop.");
      return;
    }
    const recognition = new Speech();
    recognition.lang = navigator.language || "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.onresult = event => {
      const transcript = event.results[0][0].transcript;
      setInput(prev => prev ? `${prev} ${transcript}` : transcript);
      setNotice("");
      inputRef.current?.focus();
    };
    recognition.onerror = () => setNotice("Couldn’t capture speech. Check microphone permission and try again.");
    recognition.start();
  }

  function deleteChat(id: string) {
    const remaining = chats.filter(c => c.id !== id);
    const next = remaining.length ? remaining : [makeChat()];
    setChats(next);
    if (activeId === id) setActiveId(next[0].id);
  }

  return (
    <main className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? "sidebar-open" : ""}`}>
        <div className="brand-row">
          <div className="brand-mark">k<span>+</span></div>
          <div className="brand-name">kations <b>only+</b></div>
          <button className="icon-btn mobile-close" onClick={() => setSidebarOpen(false)} aria-label="Close menu">×</button>
        </div>
        <button className="new-chat" onClick={newChat}><span>＋</span> New conversation</button>
        <div className="side-label">YOUR SPACE</div>
        <div className="history-list">
          {chats.map(chat => (
            <div className={`history-item ${chat.id === activeId ? "selected" : ""}`} key={chat.id}>
              <button onClick={() => { setActiveId(chat.id); setSidebarOpen(false); }} className="history-title">
                <span className="history-dot">◌</span><span>{chat.title}</span>
              </button>
              <button className="delete-chat" onClick={() => deleteChat(chat.id)} aria-label="Delete conversation">×</button>
            </div>
          ))}
        </div>
        <div className="sidebar-bottom">
          <div className="profile-avatar">K</div>
          <div><div className="profile-name">kations only+</div><div className="profile-caption">Your creative workspace</div></div>
          <span className="status-dot" />
        </div>
      </aside>

      {sidebarOpen && <button className="scrim" onClick={() => setSidebarOpen(false)} aria-label="Close sidebar" />}

      <section className="main-panel">
        <header className="topbar">
          <button className="icon-btn menu-toggle" onClick={() => setSidebarOpen(true)} aria-label="Open menu">☰</button>
          <div className="model-pill"><span className="live-dot" /> K+ Intelligence <span className="pill-chevron">⌄</span></div>
          <div className="topbar-right"><span className="secure-label"><span>✧</span> Made for possibilities</span></div>
        </header>

        <div className={`conversation ${messages.length ? "has-messages" : ""}`}>
          {messages.length === 0 ? (
            <div className="welcome">
              <div className="eyebrow"><span className="sparkle">✦</span> YOUR IDEAS, UNLIMITED</div>
              <h1>What will you<br /><span>make possible?</span></h1>
              <p className="welcome-sub">A little curiosity can take you anywhere.<br className="desktop-break" /> Ask, create, explore — start with anything.</p>
              <div className="starter-grid">
                {starters.map(s => (
                  <button className="starter-card" key={s.title} onClick={() => { setInput(s.prompt); inputRef.current?.focus(); }}>
                    <span className="starter-icon">{s.icon}</span>
                    <span className="starter-title">{s.title}</span>
                    <span className="starter-arrow">↗</span>
                    <span className="starter-prompt">{s.prompt}</span>
                  </button>
                ))}
              </div>
              <div className="welcome-foot"><span className="tiny-star">✳</span> Powered by AI. Guided by your imagination.</div>
            </div>
          ) : (
            <div className="message-list">
              {messages.map((m, i) => (
                <div className={`message-row ${m.role}`} key={i}>
                  <div className={`message-avatar ${m.role === "assistant" ? "ai-avatar" : "user-avatar"}`}>{m.role === "assistant" ? "✦" : "Y"}</div>
                  <div className="message-body">
                    <div className="message-author">{m.role === "assistant" ? "kations only+" : "You"}</div>
                    <div className="message-content">{m.content}</div>
                    {m.image && <img className="generated-image" src={m.image} alt="AI generated artwork" />}
                  </div>
                </div>
              ))}
              {busy && <div className="message-row assistant"><div className="message-avatar ai-avatar">✦</div><div className="message-body"><div className="message-author">kations only+</div><div className="typing"><i/><i/><i/></div></div></div>}
              <div ref={bottomRef} />
            </div>
          )}
        </div>

        <div className="composer-area">
          {notice && <div className="notice" role="status">{notice}<button onClick={() => setNotice("")}>Dismiss</button></div>}
          <form className="composer" onSubmit={e => submitMessage(e)}>
            {imageMode && <div className="mode-label"><span>✧</span> Image creation mode <button type="button" onClick={() => setImageMode(false)}>Cancel</button></div>}
            <textarea
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submitMessage(); } }}
              placeholder={imageMode ? "Describe the image you want to create..." : "Message kations only+..."}
              rows={1}
              aria-label="Message"
            />
            <div className="composer-tools">
              <div className="tool-group">
                <button type="button" className={`tool-btn ${imageMode ? "tool-active" : ""}`} onClick={() => setImageMode(v => !v)} title="Create an image"><span>▧</span> <span className="tool-text">Create image</span></button>
                <span className="tool-divider" />
                <button type="button" className="tool-btn voice-btn" onClick={startVoiceInput} title="Voice input"><span>♩</span> <span className="tool-text">Voice</span></button>
              </div>
              <button className="send-btn" type="submit" disabled={busy || !input.trim()} aria-label="Send message">{busy ? <span className="send-spinner"/> : "↑"}</button>
            </div>
          </form>
          <div className="disclaimer">AI can make mistakes. Check important information. <span>•</span> Your chats stay in this browser.</div>
        </div>
      </section>
    </main>
  );
}

interface SpeechRecognition extends EventTarget {
  lang: string; interimResults: boolean; maxAlternatives: number;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: (() => void) | null;
  start(): void;
}
interface SpeechRecognitionEvent extends Event {
  results: { [index: number]: { [index: number]: { transcript: string } } };
}
