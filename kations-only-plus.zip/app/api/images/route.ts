import OpenAI from "openai";
import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(request: Request) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "The site owner needs to add OPENAI_API_KEY in the deployment settings." }, { status: 503 });
    }
    const { prompt } = await request.json();
    if (typeof prompt !== "string" || !prompt.trim()) {
      return NextResponse.json({ error: "Describe the image you want." }, { status: 400 });
    }
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const result = await client.images.generate({
      model: "gpt-image-1",
      prompt: prompt.trim().slice(0, 3000),
      size: "1024x1024"
    });
    const image = result.data?.[0]?.b64_json;
    if (!image) throw new Error("The image model did not return image data.");
    return NextResponse.json({
      image: `data:image/png;base64,${image}`,
      revised_prompt: result.data?.[0]?.revised_prompt || ""
    });
  } catch (error) {
    console.error("Image API error:", error);
    return NextResponse.json({ error: "Image generation failed. Check that image generation is enabled for your API account." }, { status: 500 });
  }
}
