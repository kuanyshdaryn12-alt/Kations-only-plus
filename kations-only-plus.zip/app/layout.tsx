import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "kations only+ — AI for everything",
  description: "Your creative AI space: chat, voice input, and image generation.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
